<?php

/**
 * Fields for Appointments
 */
interface EAAppointmentFields
{
    // because PHP 5.2
//	const ID          = 'id';
//	const LOCATION    = 'location';
//	const SERVICE     = 'service';
//	const WORKER      = 'worker';
//	const NAME        = 'name';
//	const EMAIL       = 'email';
//	const PHONE       = 'phone';
//	const DATE        = 'date';
//	const START       = 'start';
//	const END         = 'end';
//	const DESCRIPTION = 'description';
//	const STATUS      = 'status';
//	const USER        = 'user';
//	const CREATED     = 'created';
//	const PRICE       = 'price';
//	const IP          = 'ip';
//	const SESSION     = 'session';

}